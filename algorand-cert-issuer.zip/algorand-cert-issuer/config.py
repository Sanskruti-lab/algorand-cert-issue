import os
from dotenv import load_dotenv
from algosdk.v2client import algod

load_dotenv()

# Algorand TestNet connection
ALGOD_ADDRESS = "https://testnet-api.algonode.cloud"
ALGOD_TOKEN = ""  # Not required for AlgoNode

def get_algod_client():
    """Return a connected Algorand client."""
    return algod.AlgodClient(ALGOD_TOKEN, ALGOD_ADDRESS)

# Load your account mnemonic from .env file
# Create a .env file with: MNEMONIC="word1 word2 ... word25"
MNEMONIC = os.getenv("MNEMONIC", "")
