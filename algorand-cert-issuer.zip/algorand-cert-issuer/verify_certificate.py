"""
verify_certificate.py
---------------------
Verifies a digital certificate by looking up its Asset ID
on the Algorand TestNet.
"""

import argparse
from config import get_algod_client


def verify_certificate(asset_id: int):
    """
    Verify a certificate by its Algorand Asset ID.

    Args:
        asset_id (int): The ASA ID of the certificate to verify

    Returns:
        dict: Certificate details if found
    """
    client = get_algod_client()

    try:
        asset_info = client.asset_info(asset_id)
        params = asset_info["params"]

        print("\n✅ Certificate Found on Algorand TestNet!")
        print("-" * 45)
        print(f"  Asset ID   : {asset_id}")
        print(f"  Name       : {params.get('name', 'N/A')}")
        print(f"  Unit       : {params.get('unit-name', 'N/A')}")
        print(f"  Total      : {params.get('total', 'N/A')}")
        print(f"  Decimals   : {params.get('decimals', 'N/A')}")
        print(f"  Creator    : {params.get('creator', 'N/A')}")
        print(f"  URL        : {params.get('url', 'N/A')}")
        print(f"  Note       : {params.get('note', 'N/A')}")
        print("-" * 45)
        print(f"  View on Explorer: https://testnet.algoexplorer.io/asset/{asset_id}")

        return asset_info

    except Exception as e:
        print(f"\n❌ Certificate not found or invalid Asset ID: {e}")
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify an Algorand certificate by Asset ID")
    parser.add_argument("--asset-id", type=int, required=True, help="The ASA Asset ID to verify")
    args = parser.parse_args()

    verify_certificate(args.asset_id)
