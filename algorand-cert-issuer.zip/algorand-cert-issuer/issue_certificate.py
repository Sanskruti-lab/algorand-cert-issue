"""
issue_certificate.py
--------------------
Issues a digital certificate as an Algorand Standard Asset (ASA)
on the Algorand TestNet.
"""

from algosdk import account, mnemonic, transaction
from config import get_algod_client, MNEMONIC


def issue_certificate(recipient_name: str, course_name: str, issue_date: str):
    """
    Issue a certificate as a unique ASA (total = 1, decimals = 0).

    Args:
        recipient_name: Full name of the certificate recipient
        course_name:    Name of the course or program
        issue_date:     Date of issue (e.g., "2024-06-01")

    Returns:
        asset_id (int): The unique ID of the issued certificate on-chain
    """
    client = get_algod_client()

    # Recover issuer account from mnemonic
    private_key = mnemonic.to_private_key(MNEMONIC)
    issuer_address = account.address_from_private_key(private_key)

    print(f"Issuer Address: {issuer_address}")

    # Get suggested transaction parameters
    params = client.suggested_params()

    # Build the ASA creation transaction
    # total=1 and decimals=0 makes this a unique, non-divisible certificate
    txn = transaction.AssetConfigTxn(
        sender=issuer_address,
        sp=params,
        total=1,                     # Only 1 copy — unique certificate
        decimals=0,                  # Non-divisible
        default_frozen=False,
        unit_name="CERT",
        asset_name=f"Certificate: {course_name}",
        manager=issuer_address,
        reserve=issuer_address,
        freeze=issuer_address,
        clawback=issuer_address,
        note=f"Issued to: {recipient_name} | Course: {course_name} | Date: {issue_date}".encode(),
        url="https://github.com/YOUR_USERNAME/algorand-cert-issuer",  # Update with your repo
    )

    # Sign the transaction
    signed_txn = txn.sign(private_key)

    # Submit to the network
    tx_id = client.send_transaction(signed_txn)
    print(f"Transaction submitted. TX ID: {tx_id}")

    # Wait for confirmation
    result = transaction.wait_for_confirmation(client, tx_id, 4)
    asset_id = result["asset-index"]

    print(f"\n✅ Certificate issued successfully!")
    print(f"   Recipient : {recipient_name}")
    print(f"   Course    : {course_name}")
    print(f"   Date      : {issue_date}")
    print(f"   Asset ID  : {asset_id}")
    print(f"   View on   : https://testnet.algoexplorer.io/asset/{asset_id}")

    return asset_id


if __name__ == "__main__":
    # Example usage — change these values
    issue_certificate(
        recipient_name="Alice Johnson",
        course_name="Algorand Blockchain Fundamentals",
        issue_date="2024-06-01"
    )
